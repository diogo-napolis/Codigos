/**
 * O problema de Josephus é um problema matemático e recreativo que envolve uma situação de eliminação iterativa de pessoas em um círculo. 
 * É nomeado em homenagem a Flávio Josefo, um historiador judeu que, segundo a lenda, teria sobrevivido a um cerco romano usando uma estratégia semelhante.
 * Este é um problema interessante que envolve conceitos matemáticos, e a solução pode ser encontrada de forma eficiente sem a necessidade de realizar eliminações reais.
 * Existem fórmulas e algoritmos eficazes para calcular a posição segura diretamente, sem a necessidade de simular o processo de eliminação.
 * 
 * Este projeto foi feito no terceiro trimestre, na disciplina de LED.
 * Utilizando a classe fornecida pelo professor: "ListaDuplamenteLigadaCircular", iremos:
 * - permitir a entrada da quantidade de indivíduos (n) e o passo (m) para o próximo indivíduo a ser “morto”
 * - utilizar para a interface com usuário: GUI – Graphics User Interface com componentes gráficos como botões, labels, entre outros de acordo com a necessidade
 * 
 */